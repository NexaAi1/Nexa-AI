
import { cn } from "@/lib/utils";

interface ChatMessageProps {
  message: {
    role: 'user' | 'assistant';
    content: string;
  };
  isLatestAssistantMessage: boolean;
}

export default function ChatMessage({ message, isLatestAssistantMessage }: ChatMessageProps) {
  const isUser = message.role === 'user';
  
  return (
    <div
      className={cn(
        "mb-4 flex items-start",
        isUser ? "justify-end" : "justify-start"
      )}
    >
      <div
        className={cn(
          "max-w-[80%] rounded-xl px-4 py-2",
          isUser
            ? "bg-nexa-primary text-nexa-background"
            : "glass-panel text-nexa-text"
        )}
      >
        {/* If this is the latest assistant message and it's currently typing, show the typing animation */}
        {isLatestAssistantMessage && !isUser ? (
          <div className={cn("prose prose-invert max-w-none typing-effect typing-cursor", !isUser && "text-nexa-text")}>
            {message.content}
          </div>
        ) : (
          <div className={cn("prose prose-invert max-w-none", !isUser && "text-nexa-text")}>
            {message.content.split('\n').map((line, i) => (
              <p key={i} className={i === 0 ? "mt-0" : undefined}>
                {line || <br />}
              </p>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
