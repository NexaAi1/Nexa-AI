
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useChat } from "@/contexts/ChatContext";
import { formatDistanceToNow } from "date-fns";

export default function Sidebar() {
  const { chats, currentChat, createNewChat, setCurrentChat, deleteChat } = useChat();

  return (
    <div className="hidden lg:flex h-screen w-[300px] flex-col border-r border-nexa-primary/10 bg-nexa-dark/50">
      <div className="p-4">
        <Button 
          onClick={createNewChat}
          className="w-full bg-nexa-primary text-nexa-background hover:bg-nexa-primary/90 button-glow"
        >
          New Chat
        </Button>
      </div>
      <ScrollArea className="flex-1">
        <div className="space-y-2 p-4">
          {chats.map((chat) => (
            <div 
              key={chat.id} 
              className={`group relative rounded-md px-3 py-2 cursor-pointer transition-all duration-200 hover:bg-nexa-primary/10 ${
                currentChat?.id === chat.id 
                  ? "bg-nexa-primary/20 text-nexa-primary" 
                  : "text-nexa-text"
              }`}
              onClick={() => setCurrentChat(chat.id)}
            >
              <div className="line-clamp-1 text-sm font-medium">
                {chat.title}
              </div>
              <div className="flex items-center justify-between text-xs text-nexa-text/70 mt-1">
                <span>
                  {chat.messages.length} message{chat.messages.length !== 1 ? "s" : ""}
                </span>
                <span>
                  {formatDistanceToNow(new Date(chat.createdAt), { addSuffix: true })}
                </span>
              </div>
              <Button
                variant="ghost"
                size="icon"
                className="absolute right-1 top-1 h-6 w-6 rounded-sm opacity-0 group-hover:opacity-100 transition-opacity"
                onClick={(e) => {
                  e.stopPropagation();
                  deleteChat(chat.id);
                }}
              >
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-x">
                  <path d="M18 6 6 18"/>
                  <path d="m6 6 12 12"/>
                </svg>
              </Button>
            </div>
          ))}
        </div>
      </ScrollArea>
    </div>
  );
}
