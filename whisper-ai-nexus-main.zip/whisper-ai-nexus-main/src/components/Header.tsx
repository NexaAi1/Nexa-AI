
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Info } from "lucide-react";

export default function Header() {
  return (
    <header className="sticky top-0 z-40 w-full bg-nexa-background/90 backdrop-blur-sm border-b border-nexa-primary/20">
      <div className="container flex h-16 items-center justify-between py-4">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-full bg-nexa-primary animate-subtle-glow flex items-center justify-center">
            <div className="text-nexa-background font-bold">N</div>
          </div>
          <h1 className="text-2xl font-bold animate-text-glow text-gradient">Nexa AI</h1>
        </div>
        
        <Dialog>
          <DialogTrigger asChild>
            <Button 
              variant="outline" 
              size="icon" 
              className="bg-nexa-background border-nexa-primary/30 hover:bg-nexa-primary/10 hover:border-nexa-primary animate-border-glow"
            >
              <Info className="h-4 w-4 text-nexa-primary" />
              <span className="sr-only">About</span>
            </Button>
          </DialogTrigger>
          <DialogContent className="glass-panel border-nexa-primary/30 bg-nexa-background">
            <DialogHeader>
              <DialogTitle className="text-nexa-text">About Nexa AI</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <p className="text-nexa-text/90">
                Nexa AI is a modern chatbot powered by Google Gemini.
              </p>
              <div className="text-center mt-6">
                <p className="text-sm text-nexa-text/70">Made by</p>
                <p className="text-lg text-nexa-primary font-medium">Farman and Ashad</p>
                <p className="text-sm text-nexa-text/60 mt-1">Nexa AI</p>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </header>
  );
}
