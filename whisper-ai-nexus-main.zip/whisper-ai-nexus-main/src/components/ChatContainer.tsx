
import { useEffect, useRef } from "react";
import { ScrollArea } from "@/components/ui/scroll-area";
import ChatMessage from "./ChatMessage";
import { useChat } from "@/contexts/ChatContext";

export default function ChatContainer() {
  const { currentChat, isLoading } = useChat();
  const scrollRef = useRef<HTMLDivElement>(null);

  // Scroll to bottom when messages change
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [currentChat?.messages]);

  return (
    <ScrollArea className="flex-1 p-4">
      <div className="space-y-4">
        {/* Welcome message */}
        {(!currentChat?.messages || currentChat.messages.length === 0) && (
          <div className="flex flex-col items-center justify-center h-full py-8 text-center">
            <div className="w-16 h-16 mb-4 rounded-full bg-nexa-primary/20 animate-subtle-glow flex items-center justify-center">
              <div className="text-nexa-primary text-2xl font-bold">N</div>
            </div>
            <h2 className="text-xl font-bold text-gradient animate-text-glow mb-2">
              Welcome to Nexa AI
            </h2>
            <p className="text-nexa-text/70 max-w-md">
              Ask me anything and I'll do my best to help. I'm powered by Google's Gemini AI.
            </p>
          </div>
        )}

        {/* Chat messages */}
        {currentChat?.messages.map((message, index) => (
          <ChatMessage 
            key={message.id} 
            message={message} 
            isLatestAssistantMessage={
              message.role === 'assistant' && 
              index === currentChat.messages.length - 1 && 
              isLoading
            } 
          />
        ))}
        
        {/* Loading indicator */}
        {isLoading && !currentChat?.messages.find(m => m.role === 'assistant') && (
          <div className="flex justify-start mb-4">
            <div className="glass-panel text-nexa-text max-w-[80%] rounded-xl px-4 py-2">
              <div className="flex space-x-2">
                <div className="w-2 h-2 rounded-full bg-nexa-primary animate-pulse"></div>
                <div className="w-2 h-2 rounded-full bg-nexa-primary animate-pulse delay-150"></div>
                <div className="w-2 h-2 rounded-full bg-nexa-primary animate-pulse delay-300"></div>
              </div>
            </div>
          </div>
        )}
        
        {/* Auto scroll anchor */}
        <div ref={scrollRef} />
      </div>
    </ScrollArea>
  );
}
