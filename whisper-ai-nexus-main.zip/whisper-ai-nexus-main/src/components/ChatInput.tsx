
import { useState, FormEvent } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Send } from "lucide-react";
import { useChat } from "@/contexts/ChatContext";

export default function ChatInput() {
  const [message, setMessage] = useState("");
  const { sendMessage, isLoading } = useChat();

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!message.trim() || isLoading) return;
    
    const userMessage = message;
    setMessage("");
    await sendMessage(userMessage);
  };

  return (
    <form onSubmit={handleSubmit} className="border-t border-nexa-primary/20 bg-nexa-background/50 p-4">
      <div className="relative flex items-center">
        <Textarea
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          placeholder="Type a message..."
          className="pr-12 resize-none border-nexa-primary/30 bg-nexa-dark/50 text-nexa-text focus-visible:ring-nexa-primary"
          onKeyDown={(e) => {
            if (e.key === "Enter" && !e.shiftKey) {
              e.preventDefault();
              handleSubmit(e);
            }
          }}
        />
        <Button
          type="submit"
          size="icon"
          disabled={!message.trim() || isLoading}
          className="absolute right-2 bg-nexa-primary text-nexa-background hover:bg-nexa-primary/90 button-glow"
        >
          <Send className="h-4 w-4" />
          <span className="sr-only">Send</span>
        </Button>
      </div>
      <div className="mt-2 text-xs text-nexa-text/70 text-center">
        Powered by Google Gemini API
      </div>
    </form>
  );
}
