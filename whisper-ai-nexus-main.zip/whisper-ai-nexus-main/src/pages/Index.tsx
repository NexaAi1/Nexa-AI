
import Header from "@/components/Header";
import Sidebar from "@/components/Sidebar";
import ChatContainer from "@/components/ChatContainer";
import ChatInput from "@/components/ChatInput";

const Index = () => {
  return (
    <div className="flex h-screen flex-col">
      <Header />
      <div className="flex flex-1 overflow-hidden">
        <Sidebar />
        <div className="flex flex-1 flex-col">
          <ChatContainer />
          <ChatInput />
        </div>
      </div>
    </div>
  );
};

export default Index;
