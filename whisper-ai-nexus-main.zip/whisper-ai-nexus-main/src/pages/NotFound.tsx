
import { useLocation } from "react-router-dom";
import { useEffect } from "react";

const NotFound = () => {
  const location = useLocation();

  useEffect(() => {
    console.error(
      "404 Error: User attempted to access non-existent route:",
      location.pathname
    );
  }, [location.pathname]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-nexa-background">
      <div className="text-center">
        <div className="w-20 h-20 mx-auto mb-6 rounded-full bg-nexa-primary/20 animate-subtle-glow flex items-center justify-center">
          <div className="text-nexa-primary text-3xl font-bold">404</div>
        </div>
        <h1 className="text-4xl font-bold mb-4 text-gradient animate-text-glow">Page Not Found</h1>
        <p className="text-xl text-nexa-text/80 mb-8">The page you are looking for doesn't exist.</p>
        <a 
          href="/" 
          className="inline-block bg-nexa-primary text-nexa-background px-6 py-3 rounded-lg hover:bg-nexa-primary/90 button-glow"
        >
          Return to Home
        </a>
      </div>
    </div>
  );
};

export default NotFound;
