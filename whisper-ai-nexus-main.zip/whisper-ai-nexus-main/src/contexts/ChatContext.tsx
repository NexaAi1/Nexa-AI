
import React, { createContext, useContext, useState, useEffect } from "react";
import { toast } from "@/components/ui/use-toast";

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

interface Chat {
  id: string;
  title: string;
  messages: Message[];
  createdAt: Date;
}

interface ChatContextProps {
  chats: Chat[];
  currentChat: Chat | null;
  apiKey: string;
  createNewChat: () => void;
  setCurrentChat: (chatId: string) => void;
  deleteChat: (chatId: string) => void;
  sendMessage: (content: string) => Promise<void>;
  isLoading: boolean;
}

const ChatContext = createContext<ChatContextProps | undefined>(undefined);

// Fixed API key - no longer requiring user input
const FIXED_API_KEY = "AIzaSyAC9CxJYzDs6aEosKwNuQ-QbnQzsC5GJ0g";

export const useChat = () => {
  const context = useContext(ChatContext);
  if (!context) {
    throw new Error("useChat must be used within a ChatProvider");
  }
  return context;
};

export const ChatProvider: React.FC<{ children: React.ReactNode }> = ({ 
  children 
}) => {
  const [chats, setChats] = useState<Chat[]>([]);
  const [currentChat, setCurrentChatState] = useState<Chat | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  // Load chats from localStorage on initial render
  useEffect(() => {
    const savedChats = localStorage.getItem("nexa_chats");
    const savedCurrentChatId = localStorage.getItem("nexa_current_chat_id");
    
    if (savedChats) {
      const parsedChats = JSON.parse(savedChats).map((chat: any) => ({
        ...chat,
        createdAt: new Date(chat.createdAt),
        messages: chat.messages.map((msg: any) => ({
          ...msg,
          timestamp: new Date(msg.timestamp),
        })),
      }));
      
      setChats(parsedChats);
      
      if (savedCurrentChatId && parsedChats.length > 0) {
        const currentChatData = parsedChats.find(
          (chat: Chat) => chat.id === savedCurrentChatId
        );
        setCurrentChatState(currentChatData || parsedChats[0]);
      } else if (parsedChats.length > 0) {
        setCurrentChatState(parsedChats[0]);
      }
    } else {
      // Create a default chat if no chats exist
      const defaultChat = createDefaultChat();
      setChats([defaultChat]);
      setCurrentChatState(defaultChat);
    }
  }, []);

  // Save chats to localStorage whenever they change
  useEffect(() => {
    if (chats.length > 0) {
      localStorage.setItem("nexa_chats", JSON.stringify(chats));
    }
    
    if (currentChat) {
      localStorage.setItem("nexa_current_chat_id", currentChat.id);
    }
  }, [chats, currentChat]);

  const createDefaultChat = (): Chat => {
    return {
      id: generateId(),
      title: "New Chat",
      messages: [],
      createdAt: new Date(),
    };
  };

  const createNewChat = () => {
    const newChat = createDefaultChat();
    setChats((prev) => [...prev, newChat]);
    setCurrentChatState(newChat);
  };

  const setCurrentChat = (chatId: string) => {
    const chat = chats.find((c) => c.id === chatId);
    if (chat) {
      setCurrentChatState(chat);
    }
  };

  const deleteChat = (chatId: string) => {
    setChats((prev) => {
      const filtered = prev.filter((chat) => chat.id !== chatId);
      
      // If we're deleting the current chat, set a new current chat
      if (currentChat?.id === chatId && filtered.length > 0) {
        setCurrentChatState(filtered[0]);
      }
      // If there are no chats left, create a new default one
      else if (filtered.length === 0) {
        const defaultChat = createDefaultChat();
        setCurrentChatState(defaultChat);
        return [defaultChat];
      }
      
      return filtered;
    });
  };

  const generateId = () => {
    return Math.random().toString(36).substring(2, 15);
  };

  const sendMessage = async (content: string) => {
    if (!currentChat) {
      createNewChat();
      return;
    }

    // Add user message
    const userMessage: Message = {
      id: generateId(),
      role: "user",
      content,
      timestamp: new Date(),
    };

    // Update the current chat with the user message first
    const updatedChat: Chat = {
      ...currentChat,
      messages: [...currentChat.messages, userMessage],
    };

    // If it's the first message, update the chat title
    if (currentChat.messages.length === 0) {
      updatedChat.title = content.substring(0, 30) + (content.length > 30 ? "..." : "");
    }

    setChats((prev) =>
      prev.map((chat) => (chat.id === currentChat.id ? updatedChat : chat))
    );
    setCurrentChatState(updatedChat);

    // Set loading state and make API call
    setIsLoading(true);

    try {
      const response = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${FIXED_API_KEY}`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            contents: [
              {
                parts: [{ text: content }],
              },
            ],
          }),
        }
      );

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error?.message || "Failed to get response from Gemini");
      }

      // Extract the response text from the Gemini API
      const aiResponse = data.candidates[0]?.content?.parts[0]?.text || "No response";

      // Add AI message
      const assistantMessage: Message = {
        id: generateId(),
        role: "assistant",
        content: aiResponse,
        timestamp: new Date(),
      };

      // Update the chat with the AI response
      const finalChat: Chat = {
        ...updatedChat,
        messages: [...updatedChat.messages, assistantMessage],
      };

      setChats((prev) =>
        prev.map((chat) => (chat.id === currentChat.id ? finalChat : chat))
      );
      setCurrentChatState(finalChat);
    } catch (error: any) {
      console.error("Error calling Gemini API:", error);
      toast({
        title: "API Error",
        description: error.message || "Failed to communicate with Gemini API",
        variant: "destructive",
      });

      // Add error message to chat
      const errorMessage: Message = {
        id: generateId(),
        role: "assistant",
        content: "Sorry, there was an error processing your request. Please try again later.",
        timestamp: new Date(),
      };

      const errorChat: Chat = {
        ...updatedChat,
        messages: [...updatedChat.messages, errorMessage],
      };

      setChats((prev) =>
        prev.map((chat) => (chat.id === currentChat.id ? errorChat : chat))
      );
      setCurrentChatState(errorChat);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <ChatContext.Provider
      value={{
        chats,
        currentChat,
        apiKey: FIXED_API_KEY,
        createNewChat,
        setCurrentChat,
        deleteChat,
        sendMessage,
        isLoading,
      }}
    >
      {children}
    </ChatContext.Provider>
  );
};
